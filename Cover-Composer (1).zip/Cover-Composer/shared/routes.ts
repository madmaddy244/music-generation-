import { z } from 'zod';
import { insertTrackSchema, tracks } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  tracks: {
    list: {
      method: 'GET' as const,
      path: '/api/tracks' as const,
      responses: {
        200: z.array(z.custom<typeof tracks.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/tracks/:id' as const,
      responses: {
        200: z.custom<typeof tracks.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/tracks' as const,
      input: insertTrackSchema,
      responses: {
        201: z.custom<typeof tracks.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type TrackInput = z.infer<typeof api.tracks.create.input>;
export type TrackResponse = z.infer<typeof api.tracks.create.responses[201]>;
export type TrackListResponse = z.infer<typeof api.tracks.list.responses[200]>;
