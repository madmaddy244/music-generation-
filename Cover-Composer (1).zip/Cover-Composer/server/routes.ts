import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

async function generateMusic(prompt: string, genre: string) {
  try {
    // Step 1: Generate lyrics using GPT
    const lyricsResponse = await openai.chat.completions.create({
      model: "gpt-5.2",
      messages: [
        {
          role: "system",
          content: `You are a professional songwriter. Create a short song with 2 verses and a chorus based on the given prompt and genre. 
Format the output as:
[Verse 1]
lyrics here

[Chorus]
lyrics here

[Verse 2]
lyrics here

Keep it concise and evocative.`
        },
        {
          role: "user",
          content: `Create a ${genre} song about: ${prompt}`
        }
      ],
      max_tokens: 500,
    });

    const lyrics = lyricsResponse.choices[0]?.message?.content || "";

    // Step 2: Generate cover art using DALL-E
    const imageResponse = await openai.images.generate({
      model: "gpt-image-1",
      prompt: `Album cover art for a ${genre} song: ${prompt}. Professional, atmospheric, music-themed. 1024x1024, high quality.`,
      size: "1024x1024",
      n: 1,
    });

    const coverArtUrl = imageResponse.data[0]?.url || "";

    // Step 3: Generate audio using text-to-speech
    // Create a spoken version of the lyrics
    const audioResponse = await openai.chat.completions.create({
      model: "gpt-audio",
      modalities: ["text", "audio"],
      audio: {
        voice: "alloy",
        format: "wav"
      },
      messages: [
        {
          role: "user",
          content: `Sing/recite these ${genre} lyrics with emotion and musicality: ${lyrics.substring(0, 300)}`
        }
      ],
    });

    const audioData = (audioResponse.choices[0]?.message as any)?.audio?.data ?? "";
    
    // Convert base64 audio to a data URL for playback
    const audioUrl = `data:audio/wav;base64,${audioData}`;

    return {
      lyrics,
      coverArtUrl,
      audioUrl
    };
  } catch (error) {
    console.error("Error generating music:", error);
    throw error;
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.tracks.list.path, async (req, res) => {
    try {
      const tracks = await storage.getTracks();
      res.json(tracks);
    } catch (error) {
      console.error("Error fetching tracks:", error);
      res.status(500).json({ message: "Failed to fetch tracks" });
    }
  });

  app.get(api.tracks.get.path, async (req, res) => {
    try {
      const track = await storage.getTrack(Number(req.params.id));
      if (!track) {
        return res.status(404).json({ message: 'Track not found' });
      }
      res.json(track);
    } catch (error) {
      console.error("Error fetching track:", error);
      res.status(500).json({ message: "Failed to fetch track" });
    }
  });

  app.post(api.tracks.create.path, async (req, res) => {
    try {
      const input = api.tracks.create.input.parse(req.body);
      
      // Generate music (lyrics, cover art, audio)
      const generated = await generateMusic(input.prompt, input.genre);
      
      // Create track with generated content
      const track = await storage.createTrackDirect({
        prompt: input.prompt,
        genre: input.genre,
        title: `${input.genre} - ${input.prompt.substring(0, 30)}...`,
        lyrics: generated.lyrics,
        coverArtUrl: generated.coverArtUrl,
        audioUrl: generated.audioUrl,
      });
      
      res.status(201).json(track);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      console.error("Error creating track:", err);
      res.status(500).json({ message: "Failed to generate music. Please try again." });
    }
  });

  // Seed database with example tracks
  async function seedDatabase() {
    try {
      const existingItems = await storage.getTracks();
      if (existingItems.length === 0) {
        console.log("Seeding database with example tracks...");
        const tracks = [
          { prompt: "A relaxing evening in a cozy café", genre: "Acoustic Pop" },
          { prompt: "Driving through neon-lit city streets at midnight", genre: "Synthwave" },
          { prompt: "Studying late into the night with calming beats", genre: "Lo-Fi" },
        ];

        for (const track of tracks) {
          try {
            const generated = await generateMusic(track.prompt, track.genre);
            await storage.createTrackDirect({
              prompt: track.prompt,
              genre: track.genre,
              title: `${track.genre} - ${track.prompt.substring(0, 30)}...`,
              lyrics: generated.lyrics,
              coverArtUrl: generated.coverArtUrl,
              audioUrl: generated.audioUrl,
            });
            console.log(`✓ Created seed track: ${track.genre}`);
          } catch (error) {
            console.error(`Failed to seed track "${track.genre}":`, error);
          }
        }
        console.log("Database seeding complete.");
      } else {
        console.log(`Database already has ${existingItems.length} tracks.`);
      }
    } catch (error) {
      console.error("Error during seeding:", error);
    }
  }

  // Seed on startup
  seedDatabase();

  return httpServer;
}