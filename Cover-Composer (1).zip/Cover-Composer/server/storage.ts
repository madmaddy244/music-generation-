import { db } from "./db";
import {
  tracks,
  type CreateTrackRequest,
  type TrackResponse
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getTracks(): Promise<TrackResponse[]>;
  getTrack(id: number): Promise<TrackResponse | undefined>;
  createTrack(track: CreateTrackRequest): Promise<TrackResponse>;
  createTrackDirect(data: {
    prompt: string;
    genre: string;
    title: string;
    lyrics: string;
    coverArtUrl: string;
    audioUrl: string;
  }): Promise<TrackResponse>;
}

export class DatabaseStorage implements IStorage {
  async getTracks(): Promise<TrackResponse[]> {
    return await db.select().from(tracks).orderBy(desc(tracks.createdAt));
  }

  async getTrack(id: number): Promise<TrackResponse | undefined> {
    const [track] = await db.select().from(tracks).where(eq(tracks.id, id));
    return track;
  }

  async createTrack(track: CreateTrackRequest): Promise<TrackResponse> {
    const title = `${track.genre} - ${track.prompt.substring(0, 30)}...`;
    const [newTrack] = await db.insert(tracks).values({
      ...track,
      title,
      lyrics: "",
      coverArtUrl: "",
      audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    }).returning();
    return newTrack;
  }

  async createTrackDirect(data: {
    prompt: string;
    genre: string;
    title: string;
    lyrics: string;
    coverArtUrl: string;
    audioUrl: string;
  }): Promise<TrackResponse> {
    const [newTrack] = await db.insert(tracks).values({
      prompt: data.prompt,
      genre: data.genre,
      title: data.title,
      lyrics: data.lyrics,
      coverArtUrl: data.coverArtUrl,
      audioUrl: data.audioUrl,
    }).returning();
    return newTrack;
  }
}

export const storage = new DatabaseStorage();
