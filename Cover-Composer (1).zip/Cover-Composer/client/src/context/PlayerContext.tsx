import React, { createContext, useContext, useState, useRef, useEffect } from "react";
import { type TrackResponse } from "@shared/routes";

interface PlayerContextType {
  currentTrack: TrackResponse | null;
  isPlaying: boolean;
  progress: number; // 0 to 1
  currentTime: number;
  duration: number;
  play: (track: TrackResponse) => void;
  pause: () => void;
  toggle: () => void;
  seek: (progress: number) => void;
}

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const [currentTrack, setCurrentTrack] = useState<TrackResponse | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(180); // Mock 3 mins default
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      
      audioRef.current.addEventListener('timeupdate', () => {
        if (audioRef.current) {
          setCurrentTime(audioRef.current.currentTime);
          if (audioRef.current.duration) {
            setDuration(audioRef.current.duration);
            setProgress(audioRef.current.currentTime / audioRef.current.duration);
          }
        }
      });

      audioRef.current.addEventListener('ended', () => {
        setIsPlaying(false);
        setProgress(0);
        setCurrentTime(0);
      });
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = "";
      }
    };
  }, []);

  const play = (track: TrackResponse) => {
    if (currentTrack?.id === track.id) {
      // Resume current
      audioRef.current?.play().catch(e => console.log("Playback prevented:", e));
      setIsPlaying(true);
    } else {
      // Load new
      setCurrentTrack(track);
      if (audioRef.current) {
        // If no real audio url, we use a silent track or just mock the progress
        // For demonstration, we'll assume audioUrl might be null and handle graceful failure
        audioRef.current.src = track.audioUrl || "https://actions.google.com/sounds/v1/alarms/beep_short.ogg"; // fallback sound
        audioRef.current.play().catch(e => console.log("Playback prevented:", e));
        setIsPlaying(true);
      }
    }
  };

  const pause = () => {
    audioRef.current?.pause();
    setIsPlaying(false);
  };

  const toggle = () => {
    if (isPlaying) {
      pause();
    } else if (currentTrack) {
      play(currentTrack);
    }
  };

  const seek = (newProgress: number) => {
    if (audioRef.current && audioRef.current.duration) {
      const time = newProgress * audioRef.current.duration;
      audioRef.current.currentTime = time;
      setProgress(newProgress);
      setCurrentTime(time);
    }
  };

  // Mock progress if no real audio
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && currentTrack && !currentTrack.audioUrl) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          const next = prev + 1;
          if (next >= duration) {
            setIsPlaying(false);
            setProgress(0);
            return 0;
          }
          setProgress(next / duration);
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentTrack, duration]);

  return (
    <PlayerContext.Provider value={{ currentTrack, isPlaying, progress, currentTime, duration, play, pause, toggle, seek }}>
      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const context = useContext(PlayerContext);
  if (context === undefined) {
    throw new Error("usePlayer must be used within a PlayerProvider");
  }
  return context;
}
