import { Play, Pause, MoreVertical } from "lucide-react";
import { type TrackResponse } from "@shared/routes";
import { usePlayer } from "@/context/PlayerContext";
import { Link } from "wouter";

interface TrackCardProps {
  track: TrackResponse;
}

export function TrackCard({ track }: TrackCardProps) {
  const { currentTrack, isPlaying, toggle, play } = usePlayer();
  const isThisPlaying = currentTrack?.id === track.id && isPlaying;

  // Unsplash fallback for cover art - abstract/music vibe
  const coverUrl = track.coverArtUrl || `https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=400&h=400&fit=crop`;

  const handlePlayClick = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigating if wrapped in a link conceptually
    if (currentTrack?.id === track.id) {
      toggle();
    } else {
      play(track);
    }
  };

  return (
    <div className="group glass-card rounded-2xl p-4 flex flex-col gap-4">
      {/* Cover Art Area */}
      <div className="relative aspect-square rounded-xl overflow-hidden bg-white/5">
        <img 
          src={coverUrl} 
          alt={track.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        
        {/* Play Overlay */}
        <div className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity duration-300 ${isThisPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
          <button 
            onClick={handlePlayClick}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 transform ${isThisPlaying ? 'bg-primary text-white scale-100 shadow-[0_0_30px_rgba(176,38,255,0.6)]' : 'bg-white text-black translate-y-4 group-hover:translate-y-0 group-hover:scale-100 scale-90 hover:bg-primary hover:text-white'}`}
          >
            {isThisPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-1" />}
          </button>
        </div>

        {/* Genre Badge */}
        <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-semibold text-white/90 uppercase tracking-wider">
          {track.genre}
        </div>
      </div>

      {/* Info Area */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <Link href={`/track/${track.id}`} className="font-display font-bold text-lg text-white truncate block hover:text-primary transition-colors">
            {track.title}
          </Link>
          <p className="text-sm text-muted-foreground truncate mt-1">
             Prompt: {track.prompt}
          </p>
        </div>
        <button className="text-muted-foreground hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors">
          <MoreVertical className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
