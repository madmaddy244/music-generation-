import { Home, Compass, Library, PlusCircle, Settings, Music2 } from "lucide-react";
import { Link, useLocation } from "wouter";

const NAV_ITEMS = [
  { href: "/", label: "Home", icon: Home },
  { href: "/explore", label: "Explore", icon: Compass },
  { href: "/library", label: "Library", icon: Library },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 border-r border-white/5 bg-background/50 backdrop-blur-3xl hidden md:flex flex-col h-screen sticky top-0">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-primary to-accent flex items-center justify-center shadow-[0_0_15px_rgba(176,38,255,0.4)]">
          <Music2 className="w-5 h-5 text-white" />
        </div>
        <span className="font-display font-bold text-xl tracking-tight text-white">CoverComposer</span>
      </div>

      <div className="px-4 py-2">
        <p className="px-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Menu</p>
        <nav className="space-y-1">
          {NAV_ITEMS.map((item) => {
            const isActive = location === item.href;
            return (
              <Link 
                key={item.href} 
                href={item.href}
                className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 ${
                  isActive 
                    ? "bg-white/10 text-white font-medium shadow-sm border border-white/5" 
                    : "text-muted-foreground hover:bg-white/5 hover:text-white"
                }`}
              >
                <item.icon className={`w-5 h-5 ${isActive ? "text-primary" : ""}`} />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto p-4">
        <button className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold bg-white/5 text-white border border-white/10 hover:bg-white/10 transition-colors">
          <Settings className="w-4 h-4" />
          Settings
        </button>
      </div>
    </aside>
  );
}
