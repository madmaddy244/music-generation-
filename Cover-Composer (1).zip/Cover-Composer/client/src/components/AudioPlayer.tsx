import { Play, Pause, SkipBack, SkipForward, Volume2, Maximize2 } from "lucide-react";
import { usePlayer } from "@/context/PlayerContext";
import { Link } from "wouter";

function formatTime(seconds: number) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function AudioPlayer() {
  const { currentTrack, isPlaying, progress, currentTime, duration, toggle, seek } = usePlayer();

  if (!currentTrack) return null;

  // Unsplash fallback for cover art
  const coverUrl = currentTrack.coverArtUrl || `https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=400&h=400&fit=crop`;

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50">
      <div className="max-w-7xl mx-auto glass-panel rounded-2xl p-4 flex items-center gap-4 md:gap-8">
        
        {/* Track Info */}
        <div className="flex items-center gap-4 w-1/3 min-w-[200px]">
          <div className="relative w-14 h-14 rounded-lg overflow-hidden flex-shrink-0 bg-white/5 border border-white/10 group">
            <img 
              src={coverUrl} 
              alt={currentTrack.title}
              className={`w-full h-full object-cover transition-transform duration-700 ${isPlaying ? 'scale-110' : 'scale-100'}`}
            />
            {isPlaying && (
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center gap-1">
                <div className="w-1 h-3 bg-primary rounded-full audio-bar"></div>
                <div className="w-1 h-4 bg-primary rounded-full audio-bar"></div>
                <div className="w-1 h-2 bg-primary rounded-full audio-bar"></div>
              </div>
            )}
          </div>
          <div className="truncate hidden sm:block">
            <Link href={`/track/${currentTrack.id}`} className="font-display font-semibold text-foreground hover:text-primary transition-colors truncate block">
              {currentTrack.title}
            </Link>
            <p className="text-xs text-muted-foreground truncate">{currentTrack.genre}</p>
          </div>
        </div>

        {/* Controls & Progress */}
        <div className="flex-1 flex flex-col items-center max-w-2xl">
          <div className="flex items-center gap-6 mb-2">
            <button className="text-muted-foreground hover:text-foreground transition-colors p-2 hidden sm:block">
              <SkipBack className="w-5 h-5 fill-current" />
            </button>
            <button 
              onClick={toggle}
              className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 hover:bg-primary hover:text-white hover:shadow-[0_0_20px_rgba(176,38,255,0.5)] transition-all duration-300"
            >
              {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-1" />}
            </button>
            <button className="text-muted-foreground hover:text-foreground transition-colors p-2 hidden sm:block">
              <SkipForward className="w-5 h-5 fill-current" />
            </button>
          </div>
          
          <div className="w-full flex items-center gap-3 text-xs text-muted-foreground font-mono">
            <span className="w-10 text-right">{formatTime(currentTime)}</span>
            <div className="flex-1 relative flex items-center group">
              {/* Progress Bar Background */}
              <div className="absolute inset-0 h-1.5 bg-white/10 rounded-full pointer-events-none"></div>
              {/* Progress Bar Fill */}
              <div 
                className="absolute left-0 h-1.5 bg-gradient-to-r from-primary to-accent rounded-full pointer-events-none group-hover:from-primary group-hover:to-secondary transition-colors"
                style={{ width: `${progress * 100}%` }}
              ></div>
              {/* Actual Input */}
              <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.001" 
                value={progress}
                onChange={(e) => seek(parseFloat(e.target.value))}
                className="relative z-10 w-full opacity-0 group-hover:opacity-100"
              />
            </div>
            <span className="w-10">{formatTime(duration)}</span>
          </div>
        </div>

        {/* Right Controls */}
        <div className="w-1/3 min-w-[150px] flex items-center justify-end gap-4 text-muted-foreground hidden md:flex">
          <button className="hover:text-foreground transition-colors">
            <Volume2 className="w-5 h-5" />
          </button>
          <div className="w-24 relative flex items-center group">
            <div className="absolute inset-0 h-1.5 bg-white/10 rounded-full pointer-events-none"></div>
            <div className="absolute left-0 h-1.5 bg-white rounded-full pointer-events-none w-2/3 group-hover:bg-primary"></div>
            <input type="range" className="relative z-10 w-full opacity-0 group-hover:opacity-100" />
          </div>
          <Link href={`/track/${currentTrack.id}`} className="hover:text-foreground transition-colors ml-2">
            <Maximize2 className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
