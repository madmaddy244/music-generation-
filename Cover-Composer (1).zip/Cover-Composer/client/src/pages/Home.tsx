import { useState } from "react";
import { useTracks, useCreateTrack } from "@/hooks/use-tracks";
import { TrackCard } from "@/components/TrackCard";
import { Sidebar } from "@/components/Sidebar";
import { Wand2, Sparkles, Loader2, Music } from "lucide-react";
import confetti from "canvas-confetti";

const GENRES = ["Pop", "Lo-Fi", "Cyberpunk", "Synthwave", "Orchestral", "Hip-Hop", "Acoustic"];

export function Home() {
  const { data: tracks, isLoading, error } = useTracks();
  const createTrack = useCreateTrack();
  
  const [prompt, setPrompt] = useState("");
  const [genre, setGenre] = useState(GENRES[0]);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) return;

    createTrack.mutate(
      { prompt, genre },
      {
        onSuccess: () => {
          setPrompt("");
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#b026ff', '#00f0ff', '#ffffff']
          });
        }
      }
    );
  };

  return (
    <div className="flex min-h-screen bg-background text-foreground pb-24">
      <Sidebar />
      
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-6xl mx-auto px-6 py-12 md:px-12">
          
          {/* Hero Generation Section */}
          <div className="relative rounded-3xl overflow-hidden mb-16 border border-white/10">
            {/* Background Effects */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-secondary/20 z-0"></div>
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=1600&h=400&fit=crop')] opacity-10 mix-blend-overlay z-0"></div>
            
            <div className="relative z-10 p-8 md:p-16 flex flex-col items-center text-center">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/20 text-sm font-medium mb-6 backdrop-blur-md">
                <Sparkles className="w-4 h-4 text-primary" />
                <span>AI Music Engine v2.0</span>
              </div>
              
              <h1 className="text-4xl md:text-6xl font-display font-extrabold mb-4 tracking-tight">
                Compose with <span className="text-gradient">Imagination</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mb-10">
                Describe the feeling, setting, or story. Our generative engine will craft a unique, studio-quality track in seconds.
              </p>

              <form onSubmit={handleGenerate} className="w-full max-w-3xl glass-panel p-2 rounded-2xl flex flex-col sm:flex-row gap-2">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    placeholder="e.g. A melancholic piano melody in a rainy cyber city..."
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    disabled={createTrack.isPending}
                    className="w-full h-14 bg-transparent border-none focus:ring-0 text-white placeholder:text-white/40 px-6 text-lg outline-none"
                  />
                </div>
                
                <div className="w-full sm:w-48 relative border-t sm:border-t-0 sm:border-l border-white/10">
                  <select
                    value={genre}
                    onChange={(e) => setGenre(e.target.value)}
                    disabled={createTrack.isPending}
                    className="w-full h-14 bg-transparent border-none text-white focus:ring-0 px-4 appearance-none outline-none cursor-pointer font-medium"
                  >
                    {GENRES.map(g => (
                      <option key={g} value={g} className="bg-background text-white">{g}</option>
                    ))}
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={!prompt || createTrack.isPending}
                  className="h-14 px-8 rounded-xl bg-primary hover:bg-primary/90 text-white font-bold flex items-center justify-center gap-2 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-[0_0_30px_rgba(176,38,255,0.4)]"
                >
                  {createTrack.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-5 h-5" />
                      Create
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Recent Tracks Section */}
          <div className="mb-8 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-display font-bold text-white mb-1 flex items-center gap-2">
                <Music className="w-6 h-6 text-secondary" />
                Community Showcase
              </h2>
              <p className="text-muted-foreground">Latest generations from CoverComposer</p>
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="glass-card rounded-2xl p-4 h-[300px] animate-pulse flex flex-col gap-4">
                  <div className="w-full aspect-square bg-white/5 rounded-xl"></div>
                  <div className="h-6 w-3/4 bg-white/5 rounded"></div>
                  <div className="h-4 w-1/2 bg-white/5 rounded"></div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="p-8 rounded-2xl border border-red-500/20 bg-red-500/10 text-red-200 text-center">
              Failed to load tracks. Please try again later.
            </div>
          ) : !tracks?.length ? (
            <div className="text-center py-24 glass-card rounded-3xl border-dashed">
              <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                <Music className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-display font-bold text-white mb-2">No tracks yet</h3>
              <p className="text-muted-foreground">Be the first to generate a masterpiece.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {tracks.map((track) => (
                <TrackCard key={track.id} track={track} />
              ))}
            </div>
          )}

        </div>
      </main>
    </div>
  );
}
