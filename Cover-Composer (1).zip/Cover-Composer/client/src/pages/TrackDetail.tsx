import { useRoute } from "wouter";
import { useTrack } from "@/hooks/use-tracks";
import { Sidebar } from "@/components/Sidebar";
import { usePlayer } from "@/context/PlayerContext";
import { Play, Pause, Heart, Share2, Download, AlignLeft, Music } from "lucide-react";

export function TrackDetail() {
  const [, params] = useRoute("/track/:id");
  const trackId = params?.id ? parseInt(params.id) : 0;
  
  const { data: track, isLoading, error } = useTrack(trackId);
  const { currentTrack, isPlaying, toggle, play } = usePlayer();

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-background">
        <Sidebar />
        <main className="flex-1 flex items-center justify-center">
          <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin"></div>
        </main>
      </div>
    );
  }

  if (error || !track) {
    return (
      <div className="flex min-h-screen bg-background">
        <Sidebar />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-display font-bold mb-2">Track not found</h2>
            <p className="text-muted-foreground">It might have been deleted or doesn't exist.</p>
          </div>
        </main>
      </div>
    );
  }

  const isThisPlaying = currentTrack?.id === track.id && isPlaying;
  // landing page hero scenic abstract music visualizer
  const coverUrl = track.coverArtUrl || `https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1000&h=1000&fit=crop`;

  const handlePlayClick = () => {
    if (currentTrack?.id === track.id) {
      toggle();
    } else {
      play(track);
    }
  };

  return (
    <div className="flex min-h-screen bg-background pb-24">
      <Sidebar />
      
      <main className="flex-1 overflow-y-auto">
        {/* Dynamic Header */}
        <div className="relative pt-20 pb-12 px-6 md:px-12 flex flex-col md:flex-row items-end gap-8 overflow-hidden">
          {/* Blur Background */}
          <div 
            className="absolute inset-0 opacity-30 blur-[100px] z-0 pointer-events-none"
            style={{ backgroundImage: `url(${coverUrl})`, backgroundSize: 'cover' }}
          ></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent z-0 pointer-events-none"></div>

          {/* Cover Art */}
          <div className="relative z-10 w-48 h-48 md:w-64 md:h-64 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] overflow-hidden flex-shrink-0 border border-white/10 group">
            <img src={coverUrl} alt={track.title} className="w-full h-full object-cover" />
            <div className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity duration-300 ${isThisPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center shadow-[0_0_30px_rgba(176,38,255,0.6)]">
                 {isThisPlaying ? (
                    <div className="flex gap-1">
                      <div className="w-1.5 h-6 bg-white rounded-full audio-bar"></div>
                      <div className="w-1.5 h-8 bg-white rounded-full audio-bar"></div>
                      <div className="w-1.5 h-5 bg-white rounded-full audio-bar"></div>
                    </div>
                 ) : (
                    <Music className="w-8 h-8 text-white" />
                 )}
              </div>
            </div>
          </div>

          {/* Track Info */}
          <div className="relative z-10 flex-1">
            <span className="inline-block px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold uppercase tracking-widest text-white mb-4">
              {track.genre}
            </span>
            <h1 className="text-5xl md:text-7xl font-display font-extrabold text-white mb-6 tracking-tight leading-none">
              {track.title}
            </h1>
            
            <div className="flex items-center gap-4">
              <button 
                onClick={handlePlayClick}
                className="h-14 px-8 rounded-full bg-primary hover:bg-primary/90 text-white font-bold flex items-center gap-3 transition-all hover:scale-105 hover:shadow-[0_0_30px_rgba(176,38,255,0.5)]"
              >
                {isThisPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-1" />}
                <span className="text-lg">{isThisPlaying ? "Pause" : "Play Track"}</span>
              </button>
              
              <button className="w-14 h-14 rounded-full glass-panel flex items-center justify-center hover:bg-white/10 transition-colors text-white">
                <Heart className="w-6 h-6" />
              </button>
              <button className="w-14 h-14 rounded-full glass-panel flex items-center justify-center hover:bg-white/10 transition-colors text-white">
                <Share2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Content Tabs Area */}
        <div className="max-w-5xl mx-auto px-6 md:px-12 py-8 grid grid-cols-1 md:grid-cols-3 gap-12">
          
          <div className="md:col-span-2 space-y-8">
            <section className="glass-card p-8 rounded-3xl">
              <h3 className="text-xl font-display font-bold text-white mb-4 flex items-center gap-2">
                <AlignLeft className="w-5 h-5 text-primary" />
                Prompt Details
              </h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                "{track.prompt}"
              </p>
            </section>

            <section className="glass-card p-8 rounded-3xl">
              <h3 className="text-xl font-display font-bold text-white mb-6 flex items-center gap-2">
                <Music className="w-5 h-5 text-secondary" />
                Lyrics
              </h3>
              <div className="space-y-6 font-medium text-lg leading-loose text-white/80">
                {track.lyrics ? (
                  track.lyrics.split('\n\n').map((stanza, i) => (
                    <p key={i} className="whitespace-pre-wrap">{stanza}</p>
                  ))
                ) : (
                  <p className="text-muted-foreground italic">Instrumental or lyrics not provided.</p>
                )}
              </div>
            </section>
          </div>

          <div className="space-y-6">
            <div className="glass-card p-6 rounded-3xl">
              <h4 className="font-display font-bold text-white mb-4">Track Info</h4>
              <div className="space-y-4 text-sm">
                <div className="flex justify-between border-b border-white/5 pb-2">
                  <span className="text-muted-foreground">Generated on</span>
                  <span className="text-white font-medium">
                    {track.createdAt ? new Date(track.createdAt).toLocaleDateString() : 'Unknown'}
                  </span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-2">
                  <span className="text-muted-foreground">Model</span>
                  <span className="text-primary font-medium">CoverComposer v2</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-2">
                  <span className="text-muted-foreground">Duration</span>
                  <span className="text-white font-medium">3:00</span>
                </div>
              </div>
              
              <button className="w-full mt-6 py-3 rounded-xl border border-white/20 text-white font-semibold flex items-center justify-center gap-2 hover:bg-white/5 transition-colors">
                <Download className="w-4 h-4" />
                Download Audio
              </button>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
