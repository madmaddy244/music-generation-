import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type TrackInput } from "@shared/routes";
import { z } from "zod";

function parseWithLogging<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

export function useTracks() {
  return useQuery({
    queryKey: [api.tracks.list.path],
    queryFn: async () => {
      const res = await fetch(api.tracks.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch tracks");
      const data = await res.json();
      return parseWithLogging(api.tracks.list.responses[200], data, "tracks.list");
    },
  });
}

export function useTrack(id: number) {
  return useQuery({
    queryKey: [api.tracks.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.tracks.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch track");
      const data = await res.json();
      return parseWithLogging(api.tracks.get.responses[200], data, "tracks.get");
    },
    enabled: !!id,
  });
}

export function useCreateTrack() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: TrackInput) => {
      const validated = api.tracks.create.input.parse(data);
      const res = await fetch(api.tracks.create.path, {
        method: api.tracks.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      const resData = await res.json();
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = parseWithLogging(api.tracks.create.responses[400], resData, "tracks.create.error");
          throw new Error(error.message);
        }
        throw new Error("Failed to create track");
      }
      return parseWithLogging(api.tracks.create.responses[201], resData, "tracks.create.success");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.tracks.list.path] });
    },
  });
}
