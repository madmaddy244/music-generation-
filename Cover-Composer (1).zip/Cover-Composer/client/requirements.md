## Packages
framer-motion | Essential for smooth, high-quality page transitions and micro-interactions
canvas-confetti | Delightful celebration effect when a track is successfully generated
@types/canvas-confetti | TypeScript definitions for canvas-confetti

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  sans: ["var(--font-body)"],
}
